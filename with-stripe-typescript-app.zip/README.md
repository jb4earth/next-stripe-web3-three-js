# Next Stripe Web3 Three JS 

A Next JS project that pulls together all the libraries needed for a slick website with web3 and web2 payment integrations. Not yet slick but we're getting there.

`yarn dev` should get you going.

## Tasks
In progress: 
- database (gcp + orbitdb maybe) @jb4earth

Help wanted: 
- CSS fixes
- Three JS updates

License: MIT
