import {

  useAddress,

} from '@thirdweb-dev/react';


export const CWload = () => {

  const address = useAddress();

  return address
};
