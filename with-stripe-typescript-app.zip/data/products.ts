const product = [
  {
    name: 'ArchiDAO NFT',
    description: 'ArchiDAO Wearable',
    id: 'archida_nft_0000',
    price: 9000,
    image:
      'https://ipfs.io/ipfs/QmPYAPNFB373TrM9TJN59RDuZgSpUDW9qvqBktaSS4vDEH?filename=nft_.png',
    attribution: 'Photo by Archidao.io',
    currency: 'USD',
  },
]
export default product
