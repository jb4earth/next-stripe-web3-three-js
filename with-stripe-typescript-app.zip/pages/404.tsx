import { NextPage } from 'next'
import Link from 'next/link'
import Layout from '../components/Layout'

const IndexPage: NextPage = () => {
  return (
    <Layout title="ArchiDAO">
    <br/><br/><br/><br/><br/><br/><br/>
    <h1>404 | NOTHING HERE</h1>
    </Layout>
  )
}

export default IndexPage
