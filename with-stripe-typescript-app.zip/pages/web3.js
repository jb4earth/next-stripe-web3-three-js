import {
  useNetwork,
  useAddress,
} from '@thirdweb-dev/react';

function delay(time) {
  return new Promise(resolve => setTimeout(resolve, time));
}
export default async function () {
var addressX = await useAddress()
return (addressX)
}
